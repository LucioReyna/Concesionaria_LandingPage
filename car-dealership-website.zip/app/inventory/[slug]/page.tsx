import { notFound } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { VehicleCard } from "@/components/ui/vehicle-card"
import { vehicles } from "@/lib/mock-data"
import { siteConfig } from "@/lib/site-config"
import { Phone, MessageCircle, Calendar, Fuel, Gauge, Settings, Palette, CheckCircle, ArrowLeft } from "lucide-react"
import type { Metadata } from "next"

interface PageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params
  const vehicle = vehicles.find((v) => v.slug === slug)

  if (!vehicle) {
    return { title: "Vehicle Not Found" }
  }

  return {
    title: `${vehicle.year} ${vehicle.make} ${vehicle.model}`,
    description: `${vehicle.condition} ${vehicle.year} ${vehicle.make} ${vehicle.model} with ${vehicle.mileage.toLocaleString()} miles. ${vehicle.highlights.join(", ")}.`,
  }
}

export async function generateStaticParams() {
  return vehicles.map((vehicle) => ({
    slug: vehicle.slug,
  }))
}

export default async function VehicleDetailPage({ params }: PageProps) {
  const { slug } = await params
  const vehicle = vehicles.find((v) => v.slug === slug)

  if (!vehicle) {
    notFound()
  }

  const formattedPrice = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(vehicle.price)

  const formattedMileage = new Intl.NumberFormat("en-US").format(vehicle.mileage)

  const relatedVehicles = vehicles
    .filter((v) => v.id !== vehicle.id && (v.make === vehicle.make || v.bodyType === vehicle.bodyType))
    .slice(0, 3)

  const specs = [
    { icon: Calendar, label: "Year", value: vehicle.year },
    { icon: Gauge, label: "Mileage", value: `${formattedMileage} mi` },
    { icon: Settings, label: "Transmission", value: vehicle.transmission },
    { icon: Fuel, label: "Fuel Type", value: vehicle.fuelType },
    { icon: Palette, label: "Exterior", value: vehicle.exteriorColor },
    { icon: Palette, label: "Interior", value: vehicle.interiorColor },
  ]

  return (
    <div className="pt-24 pb-20">
      <div className="container mx-auto px-4">
        {/* Back Link */}
        <Link
          href="/inventory"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Inventory
        </Link>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Left: Gallery */}
          <div className="lg:col-span-3 space-y-4">
            {/* Main Image */}
            <div className="relative aspect-[16/10] rounded-2xl overflow-hidden border border-border">
              <Image
                src={vehicle.images[0] || "/placeholder.svg"}
                alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                fill
                className="object-cover"
                priority
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <Badge
                  variant={
                    vehicle.condition === "New"
                      ? "default"
                      : vehicle.condition === "Certified"
                        ? "secondary"
                        : "outline"
                  }
                >
                  {vehicle.condition}
                </Badge>
              </div>
            </div>

            {/* Thumbnail Gallery */}
            <div className="grid grid-cols-3 gap-4">
              {vehicle.images.map((image, index) => (
                <div
                  key={index}
                  className="relative aspect-[16/10] rounded-xl overflow-hidden border border-border hover:border-primary/50 transition-colors cursor-pointer"
                >
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${vehicle.year} ${vehicle.make} ${vehicle.model} - Image ${index + 1}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Right: Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Title & Price */}
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                {vehicle.year} {vehicle.make} {vehicle.model}
              </h1>
              <p className="text-3xl md:text-4xl font-bold text-primary">{formattedPrice}</p>
            </div>

            {/* CTAs */}
            <div className="flex flex-col gap-3">
              <Button asChild size="lg" className="w-full">
                <Link href={`/contact?type=quote&vehicle=${vehicle.slug}`}>
                  <Phone className="w-4 h-4 mr-2" />
                  Request a Quote
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="w-full bg-transparent">
                <Link href={`/contact?type=test-drive&vehicle=${vehicle.slug}`}>
                  <Calendar className="w-4 h-4 mr-2" />
                  Book Test Drive
                </Link>
              </Button>
              <Button asChild size="lg" variant="secondary" className="w-full">
                <a href={siteConfig.whatsappLink} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  WhatsApp
                </a>
              </Button>
            </div>

            {/* Key Specs */}
            <Card>
              <CardContent className="p-4">
                <h2 className="font-semibold mb-4">Key Specifications</h2>
                <div className="grid grid-cols-2 gap-4">
                  {specs.map((spec) => (
                    <div key={spec.label} className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <spec.icon className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">{spec.label}</p>
                        <p className="text-sm font-medium">{spec.value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Highlights */}
            <Card>
              <CardContent className="p-4">
                <h2 className="font-semibold mb-4">Highlights</h2>
                <ul className="space-y-2">
                  {vehicle.highlights.map((highlight, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                      {highlight}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Financing Teaser */}
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-4">
                <h2 className="font-semibold mb-2">Financing Available</h2>
                <p className="text-sm text-muted-foreground mb-4">
                  Get pre-approved in minutes with rates as low as 2.9% APR.
                </p>
                <Button asChild variant="outline" size="sm">
                  <Link href="/financing">View Financing Options</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Features */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Features & Equipment</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {vehicle.features.map((feature, index) => (
              <div key={index} className="flex items-center gap-2 p-3 rounded-lg bg-card border border-border">
                <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                <span className="text-sm">{feature}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Related Vehicles */}
        {relatedVehicles.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Similar Vehicles</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedVehicles.map((v) => (
                <VehicleCard key={v.id} vehicle={v} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

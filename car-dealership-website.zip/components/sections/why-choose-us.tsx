import { Shield, DollarSign, HeadphonesIcon, MapPin, Star, Car, Clock } from "lucide-react"

const valueProps = [
  {
    icon: Shield,
    title: "Certified Inspections",
    description: "Every vehicle undergoes a rigorous 150-point inspection before hitting our lot.",
  },
  {
    icon: DollarSign,
    title: "Transparent Pricing",
    description: "No hidden fees, no surprises. The price you see is the price you pay.",
  },
  {
    icon: HeadphonesIcon,
    title: "Post-Sale Support",
    description: "Our relationship doesn't end at purchase. We're here for ongoing service and support.",
  },
  {
    icon: MapPin,
    title: "Trusted Local Dealer",
    description: "Serving our community for over 15 years with integrity and excellence.",
  },
]

const metrics = [
  { icon: Star, value: "4.8★", label: "Average Rating" },
  { icon: Car, value: "1,200+", label: "Cars Sold" },
  { icon: Clock, value: "Same-Day", label: "Test Drives" },
]

export function WhyChooseUs() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose AutoElite?</h2>
          <p className="text-muted-foreground text-lg">
            We're not just selling cars — we're building lasting relationships based on trust, transparency, and
            exceptional service.
          </p>
        </div>

        {/* Value Props */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {valueProps.map((prop) => (
            <div
              key={prop.title}
              className="p-6 rounded-2xl bg-card border border-border hover:border-primary/50 transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <prop.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">{prop.title}</h3>
              <p className="text-sm text-muted-foreground">{prop.description}</p>
            </div>
          ))}
        </div>

        {/* Metrics */}
        <div className="flex flex-wrap justify-center gap-8 lg:gap-16">
          {metrics.map((metric) => (
            <div key={metric.label} className="text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <metric.icon className="w-5 h-5 text-primary" />
                <span className="text-3xl md:text-4xl font-bold">{metric.value}</span>
              </div>
              <p className="text-sm text-muted-foreground">{metric.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

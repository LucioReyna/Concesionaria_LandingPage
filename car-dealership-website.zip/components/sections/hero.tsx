import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Shield, Wallet, Wrench } from "lucide-react"

const trustPills = [
  { icon: Shield, text: "Certified Used" },
  { icon: Wallet, text: "Flexible Financing" },
  { icon: Wrench, text: "Service Warranty" },
]

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('/placeholder.svg?height=1080&width=1920')`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-32 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance">
            Find Your Next Car — <span className="text-primary">Fast, Transparent, Trusted.</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Browse our curated inventory of premium vehicles. Enjoy flexible financing options, certified inspections,
            and exceptional service — all in one place.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button asChild size="lg" className="w-full sm:w-auto text-base px-8">
              <Link href="/inventory">View Inventory</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="w-full sm:w-auto text-base px-8 bg-transparent">
              <Link href="/contact?type=quote">Request a Quote</Link>
            </Button>
          </div>

          {/* Trust Pills */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-8">
            {trustPills.map((pill) => (
              <div
                key={pill.text}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-card/50 backdrop-blur-sm border border-border"
              >
                <pill.icon className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">{pill.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-2">
          <div className="w-1 h-2 rounded-full bg-muted-foreground/50" />
        </div>
      </div>
    </section>
  )
}

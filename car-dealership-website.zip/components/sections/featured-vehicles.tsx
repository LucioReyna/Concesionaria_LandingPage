import Link from "next/link"
import { Button } from "@/components/ui/button"
import { VehicleCard } from "@/components/ui/vehicle-card"
import { vehicles } from "@/lib/mock-data"

const filterChips = ["New", "Used", "Under $50k", "SUV", "Sedan", "Luxury"]

export function FeaturedVehicles() {
  const featuredVehicles = vehicles.filter((v) => v.isFeatured).slice(0, 6)

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Vehicles</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Hand-picked selection of our finest vehicles, ready for immediate delivery.
          </p>
        </div>

        {/* Filter Chips Preview */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {filterChips.map((chip) => (
            <Link
              key={chip}
              href={`/inventory?filter=${chip.toLowerCase().replace(" ", "-")}`}
              className="px-4 py-2 rounded-full text-sm font-medium bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              {chip}
            </Link>
          ))}
        </div>

        {/* Vehicle Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredVehicles.map((vehicle) => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} />
          ))}
        </div>

        {/* View All CTA */}
        <div className="text-center mt-12">
          <Button asChild size="lg" variant="outline">
            <Link href="/inventory">View All Inventory</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

"use client"

import { useState, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { VehicleCard } from "@/components/ui/vehicle-card"
import { vehicles, filterOptions } from "@/lib/mock-data"
import { Search, SlidersHorizontal, X } from "lucide-react"

const ITEMS_PER_PAGE = 9

export default function InventoryPage() {
  const [search, setSearch] = useState("")
  const [condition, setCondition] = useState("All")
  const [make, setMake] = useState("All")
  const [priceRange, setPriceRange] = useState(0)
  const [yearRange, setYearRange] = useState(0)
  const [sort, setSort] = useState("featured")
  const [showFilters, setShowFilters] = useState(false)
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE)

  const filteredVehicles = useMemo(() => {
    let result = [...vehicles]

    // Search filter
    if (search) {
      const searchLower = search.toLowerCase()
      result = result.filter(
        (v) =>
          v.make.toLowerCase().includes(searchLower) ||
          v.model.toLowerCase().includes(searchLower) ||
          `${v.year}`.includes(searchLower),
      )
    }

    // Condition filter
    if (condition !== "All") {
      result = result.filter((v) => v.condition === condition)
    }

    // Make filter
    if (make !== "All") {
      result = result.filter((v) => v.make === make)
    }

    // Price range filter
    const selectedPriceRange = filterOptions.priceRanges[priceRange]
    result = result.filter((v) => v.price >= selectedPriceRange.min && v.price <= selectedPriceRange.max)

    // Year range filter
    const selectedYearRange = filterOptions.yearRanges[yearRange]
    result = result.filter((v) => v.year >= selectedYearRange.min && v.year <= selectedYearRange.max)

    // Sorting
    switch (sort) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-desc":
        result.sort((a, b) => b.price - a.price)
        break
      case "year-desc":
        result.sort((a, b) => b.year - a.year)
        break
      case "year-asc":
        result.sort((a, b) => a.year - b.year)
        break
      case "mileage-asc":
        result.sort((a, b) => a.mileage - b.mileage)
        break
      case "featured":
      default:
        result.sort((a, b) => (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0))
    }

    return result
  }, [search, condition, make, priceRange, yearRange, sort])

  const visibleVehicles = filteredVehicles.slice(0, visibleCount)
  const hasMore = visibleCount < filteredVehicles.length

  const clearFilters = () => {
    setSearch("")
    setCondition("All")
    setMake("All")
    setPriceRange(0)
    setYearRange(0)
    setSort("featured")
  }

  const hasActiveFilters = search || condition !== "All" || make !== "All" || priceRange !== 0 || yearRange !== 0

  return (
    <div className="pt-24 pb-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Our Inventory</h1>
          <p className="text-muted-foreground">Browse {filteredVehicles.length} vehicles available</p>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search by make, model, or year..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Sort */}
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="w-full lg:w-48">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              {filterOptions.sortOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Filter Toggle (Mobile) */}
          <Button variant="outline" className="lg:hidden bg-transparent" onClick={() => setShowFilters(!showFilters)}>
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            Filters
            {hasActiveFilters && <span className="ml-2 w-2 h-2 rounded-full bg-primary" />}
          </Button>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <aside className={`lg:w-64 flex-shrink-0 space-y-6 ${showFilters ? "block" : "hidden lg:block"}`}>
            <div className="bg-card rounded-xl border border-border p-4 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold">Filters</h2>
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X className="w-4 h-4 mr-1" />
                    Clear
                  </Button>
                )}
              </div>

              {/* Condition */}
              <div className="space-y-2">
                <Label>Condition</Label>
                <Select value={condition} onValueChange={setCondition}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.conditions.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Make */}
              <div className="space-y-2">
                <Label>Make</Label>
                <Select value={make} onValueChange={setMake}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.makes.map((m) => (
                      <SelectItem key={m} value={m}>
                        {m}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Price Range */}
              <div className="space-y-2">
                <Label>Price Range</Label>
                <Select value={priceRange.toString()} onValueChange={(v) => setPriceRange(Number.parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.priceRanges.map((range, i) => (
                      <SelectItem key={range.label} value={i.toString()}>
                        {range.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Year Range */}
              <div className="space-y-2">
                <Label>Year</Label>
                <Select value={yearRange.toString()} onValueChange={(v) => setYearRange(Number.parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.yearRanges.map((range, i) => (
                      <SelectItem key={range.label} value={i.toString()}>
                        {range.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </aside>

          {/* Vehicle Grid */}
          <div className="flex-1">
            {filteredVehicles.length === 0 ? (
              <div className="text-center py-16 bg-card rounded-xl border border-border">
                <p className="text-lg font-semibold mb-2">No vehicles found</p>
                <p className="text-muted-foreground mb-4">Try adjusting your filters or search terms.</p>
                <Button variant="outline" onClick={clearFilters}>
                  Clear Filters
                </Button>
              </div>
            ) : (
              <>
                <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {visibleVehicles.map((vehicle) => (
                    <VehicleCard key={vehicle.id} vehicle={vehicle} />
                  ))}
                </div>

                {hasMore && (
                  <div className="text-center mt-10">
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={() => setVisibleCount((prev) => prev + ITEMS_PER_PAGE)}
                    >
                      Load More ({filteredVehicles.length - visibleCount} remaining)
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Percent, ArrowLeftRight, Zap, Calendar, CheckCircle } from "lucide-react"

const benefits = [
  { icon: Percent, text: "0% APR Offers Available" },
  { icon: ArrowLeftRight, text: "Trade-In Welcome" },
  { icon: Zap, text: "Fast Approval Process" },
  { icon: Calendar, text: "Flexible Payment Terms" },
]

export function FinancingTeaser() {
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    budget: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitted, setIsSubmitted] = useState(false)

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    if (!formData.name.trim()) newErrors.name = "Name is required"
    if (!formData.phone.trim()) newErrors.phone = "Phone is required"
    else if (!/^\d{10,}$/.test(formData.phone.replace(/\D/g, ""))) {
      newErrors.phone = "Enter a valid phone number"
    }
    if (!formData.budget.trim()) newErrors.budget = "Budget is required"
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      setIsSubmitted(true)
      toast({
        title: "Pre-approval request submitted!",
        description: "We'll contact you within 15 minutes.",
      })
    }
  }

  return (
    <section className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Content */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Flexible Financing Made Simple</h2>
              <p className="text-muted-foreground text-lg">
                Get behind the wheel faster with our streamlined financing process. Whether you have perfect credit or
                are rebuilding, we have options for you.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {benefits.map((benefit) => (
                <div key={benefit.text} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-sm font-medium">{benefit.text}</span>
                </div>
              ))}
            </div>

            <Button asChild size="lg">
              <Link href="/financing">See Financing Options</Link>
            </Button>
          </div>

          {/* Right: Mini Pre-Approval Form */}
          <div className="bg-secondary/50 rounded-2xl p-6 md:p-8 border border-border">
            <h3 className="text-xl font-semibold mb-2">Get Pre-Approved</h3>
            <p className="text-sm text-muted-foreground mb-6">Quick check with no impact to your credit score</p>

            {isSubmitted ? (
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <CheckCircle className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-lg">Request Submitted!</p>
                  <p className="text-sm text-muted-foreground mt-1">Our team will contact you within 15 minutes.</p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="preapproval-name">Full Name</Label>
                  <Input
                    id="preapproval-name"
                    placeholder="John Smith"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className={errors.name ? "border-destructive" : ""}
                  />
                  {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="preapproval-phone">Phone Number</Label>
                  <Input
                    id="preapproval-phone"
                    type="tel"
                    placeholder="(555) 123-4567"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={errors.phone ? "border-destructive" : ""}
                  />
                  {errors.phone && <p className="text-xs text-destructive">{errors.phone}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="preapproval-budget">Monthly Budget</Label>
                  <Input
                    id="preapproval-budget"
                    placeholder="$500 - $800/mo"
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                    className={errors.budget ? "border-destructive" : ""}
                  />
                  {errors.budget && <p className="text-xs text-destructive">{errors.budget}</p>}
                </div>

                <Button type="submit" className="w-full">
                  Check My Options
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

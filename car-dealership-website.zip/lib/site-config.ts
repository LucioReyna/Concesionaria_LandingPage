// Brand configuration - easy to swap for different dealerships
export const siteConfig = {
  name: "AutoElite Motors",
  tagline: "Premium Pre-Owned & New Vehicles",
  description:
    "Find your perfect vehicle at AutoElite Motors. Certified pre-owned cars, flexible financing, and exceptional service.",

  // Contact
  phone: "(555) 123-4567",
  email: "sales@autoelitemotors.com",
  whatsappLink: "https://wa.me/15551234567",

  // Address
  address: {
    street: "1250 Auto Drive",
    city: "Los Angeles",
    state: "CA",
    zip: "90210",
    full: "1250 Auto Drive, Los Angeles, CA 90210",
  },

  // Hours
  hours: {
    weekdays: "Mon - Fri: 9:00 AM - 8:00 PM",
    saturday: "Sat: 9:00 AM - 6:00 PM",
    sunday: "Sun: 10:00 AM - 5:00 PM",
  },

  // Social
  social: {
    facebook: "https://facebook.com/autoelitemotors",
    instagram: "https://instagram.com/autoelitemotors",
    twitter: "https://twitter.com/autoelitemotors",
    youtube: "https://youtube.com/autoelitemotors",
  },

  // Branding
  accentColor: "electric-blue",
  showPoweredBy: true,
  poweredByText: "Powered by IntroData",
}

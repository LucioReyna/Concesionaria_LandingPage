import { Hero } from "@/components/sections/hero"
import { FeaturedVehicles } from "@/components/sections/featured-vehicles"
import { FinancingTeaser } from "@/components/sections/financing-teaser"
import { WhyChooseUs } from "@/components/sections/why-choose-us"
import { Testimonials } from "@/components/sections/testimonials"
import { LeadCapture } from "@/components/sections/lead-capture"
import { ContactLocation } from "@/components/sections/contact-location"

export default function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedVehicles />
      <FinancingTeaser />
      <WhyChooseUs />
      <Testimonials />
      <LeadCapture />
      <ContactLocation />
    </>
  )
}
